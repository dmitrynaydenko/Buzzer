﻿// ScreenCaptureTest.pas - Тестовое приложение для захвата экрана (простая версия)

{$apptype windows}
{$reference System.dll}
{$reference System.Drawing.dll}
{$reference System.Windows.Forms.dll}

uses
  System,
  System.Drawing,
  System.Drawing.Imaging,
  System.Windows.Forms,
  System.Threading,
  System.Collections.Generic,
  System.Runtime.InteropServices;

[DllImport('user32.dll')]
function GetSystemMetrics(nIndex: integer): integer; external;

[DllImport('gdi32.dll')]
function GetDeviceCaps(hdc: IntPtr; nIndex: integer): integer; external;

[DllImport('user32.dll')]
function GetDC(hWnd: IntPtr): IntPtr; external;

[DllImport('user32.dll')]
function ReleaseDC(hWnd: IntPtr; hDC: IntPtr): integer; external;

const
  SM_CXSCREEN = 0;
  SM_CYSCREEN = 1;
  DESKTOPVERTRES = 117;
  DESKTOPHORZRES = 118;
  
  TARGET_WIDTH = 640;
  TARGET_HEIGHT = 480;

type
  ScreenCaptureForm = class(System.Windows.Forms.Form)
  private
    BtnCapture: Button;
    BtnStop: Button;
    LblStatus: System.Windows.Forms.Label;
    PicBox: System.Windows.Forms.PictureBox;
    TimerStats: System.Windows.Forms.Timer;
    TimerUI: System.Windows.Forms.Timer;
    
    IsCapturing: boolean;
    CaptureThread: Thread;
    FrameRate: integer;
    FramesCount: integer;
    
    PendingBitmap: Bitmap;
    PendingBitmapReady: boolean;
    BitmapLock: Object;
    
    ScreenWidth: integer;
    ScreenHeight: integer;
    
    procedure BtnCaptureClick(sender: Object; e: EventArgs);
    procedure BtnStopClick(sender: Object; e: EventArgs);
    procedure TimerStatsTick(sender: Object; e: EventArgs);
    procedure TimerUITick(sender: Object; e: EventArgs);
    procedure CaptureLoop();
    procedure GetScreenSize();
    
  public
    constructor Create();
  end;

constructor ScreenCaptureForm.Create();
begin
  inherited Create();
  
  Self.Text := 'Screen Capture Test';
  Self.Width := 800;
  Self.Height := 600;
  Self.StartPosition := System.Windows.Forms.FormStartPosition.CenterScreen;
  Self.BackColor := System.Drawing.Color.FromArgb(30, 30, 35);
  Self.FormBorderStyle := System.Windows.Forms.FormBorderStyle.FixedSingle;
  Self.MaximizeBox := false;
  
  BtnCapture := new Button();
  BtnCapture.Text := 'START CAPTURE';
  BtnCapture.Location := new System.Drawing.Point(10, 10);
  BtnCapture.Size := new System.Drawing.Size(120, 30);
  BtnCapture.BackColor := System.Drawing.Color.FromArgb(40, 167, 69);
  BtnCapture.ForeColor := System.Drawing.Color.White;
  BtnCapture.FlatStyle := System.Windows.Forms.FlatStyle.Flat;
  BtnCapture.Click += BtnCaptureClick;
  
  BtnStop := new Button();
  BtnStop.Text := 'STOP';
  BtnStop.Location := new System.Drawing.Point(140, 10);
  BtnStop.Size := new System.Drawing.Size(80, 30);
  BtnStop.BackColor := System.Drawing.Color.FromArgb(220, 53, 69);
  BtnStop.ForeColor := System.Drawing.Color.White;
  BtnStop.FlatStyle := System.Windows.Forms.FlatStyle.Flat;
  BtnStop.Click += BtnStopClick;
  BtnStop.Enabled := false;
  
  LblStatus := new System.Windows.Forms.Label();
  LblStatus.Text := 'Status: Ready';
  LblStatus.Location := new System.Drawing.Point(10, 50);
  LblStatus.Size := new System.Drawing.Size(500, 25);
  LblStatus.ForeColor := System.Drawing.Color.LightGray;
  
  PicBox := new System.Windows.Forms.PictureBox();
  PicBox.Location := new System.Drawing.Point(10, 80);
  PicBox.Size := new System.Drawing.Size(760, 470);
  PicBox.BackColor := System.Drawing.Color.FromArgb(20, 20, 25);
  PicBox.SizeMode := System.Windows.Forms.PictureBoxSizeMode.Zoom;
  PicBox.BorderStyle := System.Windows.Forms.BorderStyle.FixedSingle;
  
  TimerStats := new System.Windows.Forms.Timer();
  TimerStats.Interval := 1000;
  TimerStats.Tick += TimerStatsTick;
  
  TimerUI := new System.Windows.Forms.Timer();
  TimerUI.Interval := 50;
  TimerUI.Tick += TimerUITick;
  TimerUI.Start();
  
  Self.Controls.Add(BtnCapture);
  Self.Controls.Add(BtnStop);
  Self.Controls.Add(LblStatus);
  Self.Controls.Add(PicBox);
  
  IsCapturing := false;
  FrameRate := 0;
  FramesCount := 0;
  PendingBitmapReady := false;
  BitmapLock := new Object();
  PendingBitmap := nil;
  
  GetScreenSize();
end;

procedure ScreenCaptureForm.GetScreenSize();
var
  hDC: IntPtr;
begin
  hDC := GetDC(IntPtr.Zero);
  if hDC <> IntPtr.Zero then
  begin
    ScreenWidth := GetDeviceCaps(hDC, DESKTOPHORZRES);
    ScreenHeight := GetDeviceCaps(hDC, DESKTOPVERTRES);
    ReleaseDC(IntPtr.Zero, hDC);
  end
  else
  begin
    ScreenWidth := Screen.PrimaryScreen.Bounds.Width;
    ScreenHeight := Screen.PrimaryScreen.Bounds.Height;
  end;
  
  LblStatus.Text := 'Status: Ready (Screen: ' + IntToStr(ScreenWidth) + 'x' + IntToStr(ScreenHeight) + 
                    ' → ' + IntToStr(TARGET_WIDTH) + 'x' + IntToStr(TARGET_HEIGHT) + ')';
end;

procedure ScreenCaptureForm.BtnCaptureClick(sender: Object; e: EventArgs);
begin
  if IsCapturing then Exit;
  
  IsCapturing := true;
  BtnCapture.Enabled := false;
  BtnStop.Enabled := true;
  LblStatus.Text := 'Status: Capturing...';
  FramesCount := 0;
  FrameRate := 0;
  
  TimerStats.Start();
  
  CaptureThread := new Thread(CaptureLoop);
  CaptureThread.IsBackground := true;
  CaptureThread.Start();
end;

procedure ScreenCaptureForm.BtnStopClick(sender: Object; e: EventArgs);
begin
  IsCapturing := false;
  
  if CaptureThread <> nil then
  begin
    try
      CaptureThread.Join(1000);
    except
    end;
    CaptureThread := nil;
  end;
  
  TimerStats.Stop();
  BtnCapture.Enabled := true;
  BtnStop.Enabled := false;
  
  // Очищаем картинку
  try
    if PicBox.Image <> nil then
    begin
      var oldBmp := PicBox.Image as Bitmap;
      if oldBmp <> nil then
        oldBmp.Dispose();
      PicBox.Image := nil;
      PicBox.Refresh();
    end;
  except
  end;
  
  LblStatus.Text := 'Status: Stopped (FPS: ' + IntToStr(FrameRate) + ')';
end;

procedure ScreenCaptureForm.TimerStatsTick(sender: Object; e: EventArgs);
begin
  FrameRate := FramesCount;
  FramesCount := 0;
  LblStatus.Text := 'Status: Capturing (FPS: ' + IntToStr(FrameRate) + ')';
end;

procedure ScreenCaptureForm.TimerUITick(sender: Object; e: EventArgs);
var
  bmp: Bitmap;
begin
  if PendingBitmapReady then
  begin
    lock BitmapLock do
    begin
      bmp := PendingBitmap;
      PendingBitmap := nil;
      PendingBitmapReady := false;
    end;
    
    if bmp <> nil then
    begin
      try
        // Показываем картинку
        if PicBox.Image <> nil then
        begin
          try
            var oldBmp := PicBox.Image as Bitmap;
            if oldBmp <> nil then
              oldBmp.Dispose();
          except
          end;
        end;
        
        PicBox.Image := bmp;
        PicBox.Refresh();
      except
        // Если ошибка - просто пропускаем кадр
        try bmp.Dispose(); except end;
      end;
    end;
  end;
end;

procedure ScreenCaptureForm.CaptureLoop();
var
  bmp: Bitmap;
  captureRect: Rectangle;
  g: Graphics;
  startTime: DateTime;
  frameInterval: integer;
  tempBmp: Bitmap;
  scaledWidth: integer;
  scaledHeight: integer;
begin
  captureRect := new Rectangle(0, 0, ScreenWidth, ScreenHeight);
  
  var scaleX := TARGET_WIDTH / ScreenWidth;
  var scaleY := TARGET_HEIGHT / ScreenHeight;
  var scale := Math.Min(scaleX, scaleY);
  
  scaledWidth := Round(ScreenWidth * scale);
  scaledHeight := Round(ScreenHeight * scale);
  
  frameInterval := 1000 div 20;
  
  while IsCapturing do
  begin
    startTime := DateTime.Now;
    
    try
      bmp := new Bitmap(captureRect.Width, captureRect.Height, PixelFormat.Format32bppArgb);
      
      g := Graphics.FromImage(bmp);
      g.CopyFromScreen(0, 0, 0, 0, captureRect.Size);
      g.Dispose();
      
      if (scaledWidth < ScreenWidth) or (scaledHeight < ScreenHeight) then
      begin
        tempBmp := new Bitmap(bmp, scaledWidth, scaledHeight);
        bmp.Dispose();
        bmp := tempBmp;
      end;
      
      lock BitmapLock do
      begin
        // Удаляем старый неиспользованный кадр
        if PendingBitmap <> nil then
        begin
          try PendingBitmap.Dispose(); except end;
          PendingBitmap := nil;
        end;
        
        PendingBitmap := bmp;
        PendingBitmapReady := true;
      end;
      
      FramesCount := FramesCount + 1;
      
      var elapsed := (DateTime.Now - startTime).TotalMilliseconds;
      if elapsed < frameInterval then
        Thread.Sleep(Round(frameInterval - elapsed));
        
    except
      on ex: Exception do
      begin
        IsCapturing := false;
        LblStatus.Text := 'Status: Error: ' + ex.Message;
        BtnCapture.Enabled := true;
        BtnStop.Enabled := false;
        Break;
      end;
    end;
  end;
end;

begin
  System.Windows.Forms.Application.EnableVisualStyles();
  System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);
  System.Windows.Forms.Application.Run(new ScreenCaptureForm());
end.