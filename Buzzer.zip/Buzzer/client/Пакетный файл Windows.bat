@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

echo ========================================
echo   CONVERT ICO TO BASE64
echo ========================================
echo.

if not exist "app.ico" (
    echo [ERROR] File app.ico not found!
    echo Please place app.ico in current folder.
    pause
    exit /b 1
)

echo Converting app.ico to Base64...
echo.

:: Создаем временный PowerShell скрипт
(
echo $bytes = [System.IO.File]::ReadAllBytes("app.ico"^);
echo $base64 = [Convert]::ToBase64String($bytes^);
echo $base64 > "icon_base64.txt";
echo Write-Host "Done!";
) > "convert.ps1"

:: Запускаем PowerShell скрипт
powershell -ExecutionPolicy Bypass -File "convert.ps1"

if errorlevel 1 (
    echo [ERROR] Failed to convert!
    del convert.ps1 2>nul
    pause
    exit /b 1
)

:: Читаем результат и форматируем
set "BASE64="
for /f "delims=" %%i in (icon_base64.txt) do set "BASE64=!BASE64!%%i"

echo.
echo ========================================
echo   RESULT
echo ========================================
echo.
echo Copy this line and paste into your code:
echo.
echo const ICON_BASE64 = '!BASE64!';
echo.
echo ========================================
echo.

:: Сохраняем результат в файл для копирования
echo const ICON_BASE64 = '!BASE64!'; > icon_const.txt

echo [OK] Also saved to: icon_const.txt
echo.

del convert.ps1 2>nul
del icon_base64.txt 2>nul

pause